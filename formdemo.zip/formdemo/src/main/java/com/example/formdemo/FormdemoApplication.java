package com.example.formdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(FormdemoApplication.class, args);
    }

}
