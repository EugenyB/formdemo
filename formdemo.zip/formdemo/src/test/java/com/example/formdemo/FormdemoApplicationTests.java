package com.example.formdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
